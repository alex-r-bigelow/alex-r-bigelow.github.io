This archive contains the Hanpuku extension for Adobe Illustrator, as well
as artifacts that were used in creating the figures in our 2016 Infovis submission.

Note that installing the extension itself with Adobe's Extension Manager may
fail; Adobe has discontinued support for that installation method. Currently,
the best way to install the extension is to follow the instructions outlined
here:

https://github.com/alex-r-bigelow/hanpuku/issues/1#issuecomment-197873242

With the extension installed, you should be able to open any of the PDF
files and run the provided code examples to edit generative aspects of the
visualizations.

index.html
==========
Each directory contains a proxy index.html file, for working on and
debugging the code in more fully-featured web development environments.
Note that each index.html file uses IDs that correspond to layers
in Illustrator documents.

About Berrics
=============
The matches.csv data in this figure was taken (with permission) from:
http://www.georgelmurphy.com/berrics/

The video submitted with the paper uses the main script.js in use, and

About HBO and SIGGRAPH
======================
Each pane in the figure was saved as a separate PDF file at each stage
of the design process.