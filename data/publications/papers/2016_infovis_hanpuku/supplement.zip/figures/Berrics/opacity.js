selection.style('opacity', function (d) {
  return d.roundNumber / 8;
});
